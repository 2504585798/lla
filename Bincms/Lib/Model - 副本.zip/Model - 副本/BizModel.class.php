<?php
class BizModel extends CommonModel{
    protected $pk   = 'pois_id';
    protected $tableName =  'pois_content';
    
}