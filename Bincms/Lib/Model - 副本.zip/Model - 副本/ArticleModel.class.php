<?php
class ArticleModel extends CommonModel{
    protected $pk   = 'article_id';
    protected $tableName =  'article';
    
}