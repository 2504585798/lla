<?php
class AdModel extends CommonModel{
    protected $pk   = 'ad_id';
    protected $tableName =  'ad';
}