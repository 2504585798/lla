<?php
class UserrankModel extends CommonModel {

    protected $pk = 'rank_id';
    protected $tableName = 'user_rank';
    protected $token = 'user_rank';

}
