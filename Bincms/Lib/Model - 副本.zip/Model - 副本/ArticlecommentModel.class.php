<?php
class ArticlecommentModel extends CommonModel{
    protected $pk   = 'comment_id';
    protected $tableName =  'article_comment';
    
}